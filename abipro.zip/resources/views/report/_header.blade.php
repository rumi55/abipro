<table style="width:100%;margin-bottom:50px;">
	<tr>
		<td class="text-center">
			<img height="100px" src="{{url_image(company('logo'))}}" >
		</td>
	</tr>
	<tr>
		<td class="text-center">
			<h3>{{company('name')}}</h3>
		</td>
	</tr>
	</table>