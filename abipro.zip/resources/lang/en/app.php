
<?php

return [
    'Departement'=>'Departemen',
    'Company'=>'Perusahaan',
    'Company Profile'=>'Profil Perusahaan',
    'Account'=>'Akun',
    'Report'=>'Laporan',
    'Voucher'=>'Voucher',
    'Journal'=>'Jurnal',
    'Ledger'=>'Buku Besar',
    'User'=>'Pengguna',
    'Users'=>'Pengguna',
    'Dashboard'=>'Dasbor',
    'Contact'=>'Kontak',
    'Contacts'=>'Kontak',
    'Journal Type'=>'Jenis Jurnal',
    'Sortir'=>'Tags',
    'Profile'=>'Profil',
];
