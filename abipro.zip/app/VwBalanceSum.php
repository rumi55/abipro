<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VwBalanceSum extends Model
{
    protected $table = 'vw_balance_sum';
}
