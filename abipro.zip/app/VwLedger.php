<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VwLedger extends Model
{
    protected $table = 'vw_ledger';



}
